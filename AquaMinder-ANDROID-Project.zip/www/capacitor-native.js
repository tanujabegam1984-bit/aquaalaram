// Native bridge for AquaMinder - Android
(async function(){
  if(!window.Capacitor) {
    console.log('Not in Capacitor, web mode');
    return;
  }
  console.log('Capacitor detected - enabling native alarms');
  try{
    const { LocalNotifications, App } = Capacitor.Plugins;
    
    // Request permission
    window.requestNativePermission = async function(){
      try{
        const result = await LocalNotifications.requestPermissions();
        console.log('Native permission:', result);
        if(result.display === 'granted'){
          showToast('Native alarms enabled! 🔔', 'success');
          return true;
        } else {
          showToast('Permission denied, using in-app alarms');
          return false;
        }
      }catch(e){
        console.error('Native perm error', e);
        return false;
      }
    };

    // Override showSystemNotification to use native
    const originalShowSystem = window.showSystemNotification;
    window.showSystemNotification = async function(title, body){
      try{
        if(!state.reminders.systemNotif) return;
        // Check permission
        const perm = await LocalNotifications.checkPermissions();
        if(perm.display !== 'granted'){
          const req = await LocalNotifications.requestPermissions();
          if(req.display !== 'granted') throw new Error('not granted');
        }
        await LocalNotifications.schedule({
          notifications: [{
            title: title,
            body: body,
            id: Math.floor(Math.random()*100000),
            schedule: { at: new Date(Date.now()+100) },
            sound: null,
            smallIcon: "ic_launcher",
            iconColor: "#0ea5e9",
            channelId: "water-reminders"
          }]
        });
        console.log('Native notification scheduled');
      }catch(e){
        console.error('Native notif failed, fallback to web', e);
        if(originalShowSystem) originalShowSystem(title, body);
      }
    };

    // Create notification channel (Android 8+)
    try{
      await LocalNotifications.createChannel({
        id: "water-reminders",
        name: "Water Reminders",
        description: "Reminds you to drink water",
        importance: 5,
        visibility: 1,
        sound: "beep.wav",
        vibration: true,
        lights: true,
        lightColor: "#0ea5e9"
      });
    }catch(e){console.log('Channel create error', e)}

    // Handle notification clicks
    LocalNotifications.addListener('localNotificationActionPerformed', (action)=>{
      console.log('Notification clicked', action);
      // Open app and show drink dialog
      if(window.showInAppAlarm){
        const total = typeof getTodayTotal === 'function' ? getTodayTotal() : 0;
        const goal = state ? state.goal : 2500;
        const remaining = Math.max(0, goal-total);
        showInAppAlarm('Time to hydrate! 💧', 'You tapped the notification - time to drink!', remaining);
      }
    });

    // Override schedule to also schedule native repeating
    const originalSchedule = window.scheduleReminders;
    window.scheduleRemindersNative = async function(){
      try{
        // Cancel all pending
        const pending = await LocalNotifications.getPending();
        if(pending.notifications.length>0){
          await LocalNotifications.cancel({notifications: pending.notifications});
        }
        if(!state.reminders.enabled || !state.reminders.systemNotif) return;
        
        // Schedule next 10 notifications
        const intervalMin = state.reminders.interval;
        if(intervalMin===5) return; // skip test mode for native
        
        const now = new Date();
        const [sh, sm] = state.reminders.start.split(':').map(Number);
        const [eh, em] = state.reminders.end.split(':').map(Number);
        
        let notifications = [];
        let nextTime = new Date(now.getTime() + intervalMin*60000);
        
        for(let i=0;i<15;i++){
          // Check if within active hours
          const h = nextTime.getHours();
          const m = nextTime.getMinutes();
          const totalMin = h*60+m;
          const startMin = sh*60+sm;
          const endMin = eh*60+em;
          
          if(totalMin >= startMin && totalMin <= endMin){
            notifications.push({
              title: "💧 Time to hydrate!",
              body: "Your body needs water - tap to log",
              id: 1000+i,
              schedule: { at: new Date(nextTime) },
              smallIcon: "ic_launcher",
              channelId: "water-reminders"
            });
          }
          nextTime = new Date(nextTime.getTime() + intervalMin*60000);
          // If beyond end time, jump to next day start
          if(totalMin > endMin){
            nextTime.setDate(nextTime.getDate()+1);
            nextTime.setHours(sh, sm, 0, 0);
          }
        }
        
        if(notifications.length>0){
          await LocalNotifications.schedule({notifications});
          console.log(`Scheduled ${notifications.length} native notifications`);
        }
      }catch(e){
        console.error('Native schedule error', e);
      }
    };

    // Hook into saveState to reschedule native
    const origSave = window.saveState;
    if(origSave){
      window.saveState = function(){
        origSave();
        if(window.scheduleRemindersNative) scheduleRemindersNative();
      };
    }

    // Initial schedule
    setTimeout(()=>{ if(window.scheduleRemindersNative) scheduleRemindersNative(); }, 1000);

    // Handle app resume
    App.addListener('appStateChange', ({isActive})=>{
      if(isActive){
        console.log('App resumed, rescheduling');
        if(window.scheduleReminders) scheduleReminders();
        if(window.scheduleRemindersNative) scheduleRemindersNative();
      }
    });

    console.log('Native bridge ready');
    showToast('Native Android alarms ready! 📱', 'success');
    
  }catch(e){
    console.error('Capacitor bridge init failed', e);
  }
})();
