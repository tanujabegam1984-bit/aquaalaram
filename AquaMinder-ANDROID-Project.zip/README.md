# AquaMinder - Android App + Web PWA

## 📱 What you have

This folder contains:
- `www/` → Your web app (PWA) - production ready
- `android/` → Native Android project (Capacitor)
- Both share same code, with native alarm bridge

## 🌐 WEB DEPLOY (Instant)

Your web app is in `www/` folder. Deploy anywhere:

**Netlify Drop (30 sec):**
1. Go to https://app.netlify.com/drop
2. Drag & drop the `www` folder
3. Done! Live link: https://your-app.netlify.app

**Vercel:**
```bash
npm i -g vercel
cd www
vercel --prod
```

**GitHub Pages:**
Upload `www` contents to repo → Settings → Pages → Enable

## 📱 ANDROID APP DEPLOY

### Option 1: Build APK on your PC (Recommended)

Requirements: Android Studio + Java 17

```bash
# On your PC/Mac:
git clone <this repo>
cd aquaminder-android
npm install

# Open in Android Studio
npx cap open android

# In Android Studio:
# Build → Build APK → Debug APK
# APK will be at android/app/build/outputs/apk/debug/app-debug.apk
# Install on phone!
```

### Option 2: Build via GitHub Actions (No Android Studio needed)

1. Push this folder to GitHub
2. GitHub will auto-build APK (workflow included in .github/workflows/)
3. Download APK from Actions → Artifacts

### Option 3: Use PWABuilder (Easiest APK without code)

1. Deploy web first (Netlify link)
2. Go to https://www.pwabuilder.com
3. Enter your Netlify URL
4. Click Build → Android → Download APK

### Option 4: Convert to AAB for Play Store

In Android Studio:
Build → Generate Signed Bundle → Android App Bundle
Upload AAB to Google Play Console

## 🔔 Native Features Enabled

- ✅ Local Notifications (exact alarms, works in background)
- ✅ Vibration
- ✅ Sound
- ✅ Boot completed (alarms persist after reboot)
- ✅ Notification channels

## 📂 Project Structure

```
aquaminder-android/
├── www/                    # Web app (your PWA)
│   ├── index.html         # Main app
│   ├── manifest.json
│   ├── sw.js
│   ├── icons/
│   └── capacitor-native.js # Native bridge (auto-added)
├── android/               # Android native project
│   └── app/src/main/
│       └── AndroidManifest.xml (with permissions)
├── capacitor.config.json
└── package.json
```

## 🚀 Quick Start for Both

```bash
# Web - test locally
cd www
python -m http.server 8000
# open http://localhost:8000

# Android - sync changes
npx cap copy android
npx cap sync android
npx cap open android
```

## 🔧 Customization

Edit `www/index.html` for app logic, then:
```bash
npx cap copy android
```

## 📱 Testing Alarms on Android

1. Install APK on phone
2. Open app → Allow notification permission when asked
3. Go to Alarms tab → Enable → Set interval to "5 sec (test)"
4. Minimize app - you should get notification in 5 seconds!
5. Tap notification → App opens with drink dialog

## 🌟 Play Store Ready Checklist

- [ ] Change app icon: android/app/src/main/res/...
- [ ] Update appId in capacitor.config.json (com.yourcompany.app)
- [ ] Generate signed APK/AAB
- [ ] Create store listing
- [ ] Add privacy policy (no data collected - local only)

Made with ❤️ in Kuchinda, Odisha
