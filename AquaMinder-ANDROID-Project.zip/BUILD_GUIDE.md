# Build Guide - Web + Android

## Web Deploy - 1 Command
```bash
cd www
# Option A: Netlify
npx netlify-cli deploy --prod --dir=.

# Option B: Just zip and drag to netlify.com/drop
zip -r web.zip www/
```

## Android APK - 2 Options

### Local Build (needs Android Studio)
```bash
npm install
npx cap open android
# Then in Android Studio: Build → Build APK
```

### Cloud Build (No setup)
1. Push to GitHub
2. Go to Actions tab
3. Download APK artifact
4. Install on phone

## Quick Test
- Web: python3 -m http.server 8000 in www/
- Android: Use 5 sec test interval to verify alarms

## Icons
Replace:
- www/icons/icon-512.png (web)
- android/app/src/main/res/mipmap-*/ic_launcher.png (android)

Use https://icon.kitchen/ to generate all sizes from one image
